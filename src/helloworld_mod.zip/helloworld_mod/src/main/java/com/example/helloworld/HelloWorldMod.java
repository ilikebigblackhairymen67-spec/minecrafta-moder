package com.example.helloworld;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafxmod.FXModLanguageProvider;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.javafxmod.FXModLanguageProvider;
import net.minecraftforge.fml.event.lifecycle.FMLLoadCompleteEvent;
import net.minecraftforge.fml.javafxmod.FXModLanguageProvider;

import com.example.helloworld.block.ModBlocks;

@Mod(HelloWorldMod.MODID)
public class HelloWorldMod {
    public static final String MODID = "helloworld";

    public HelloWorldMod() {
        IEventBus modEventBus = ModLoadingContext.getInstance().getModEventBus();

        ModBlocks.register(modEventBus);

        modEventBus.addListener(this::commonSetup);
    }

    private void commonSetup(final FMLCommonSetupEvent event) {
    }

    @Mod.EventBusSubscriber(modid = MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
    public static class ClientModEvents {
        @Mod.EventHandler
        public static void onClientSetup(FMLClientSetupEvent event) {
        }
    }
}
