package com.huawei.mod;

import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Fireball;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.LivingEntity;

public class HuaweiY9sItem extends Item {

    public HuaweiY9sItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide) {
            // Right click: special attack or fireball
            long currentTime = System.currentTimeMillis();
            if (stack.hasTag() && currentTime - stack.getTag().getLong("lastUse") < 700) {
                return InteractionResultHolder.pass(stack);
            }
            stack.getOrCreateTag().putLong("lastUse", currentTime);

            // Shoot fireball
            Vec3 look = player.getLookAngle();
            Fireball fireball = new Fireball(level, player, look.x * 2, look.y * 2, look.z * 2, 1);
            fireball.setPos(player.getX() + look.x * 1.5, player.getY() + player.getEyeHeight() - 0.2, player.getZ() + look.z * 1.5);
            level.addFreshEntity(fireball);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

}
